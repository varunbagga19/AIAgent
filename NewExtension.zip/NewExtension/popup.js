document.getElementById("button").addEventListener('click',async function(){

    console.log("HI im here");

    let value = document.getElementById("helper").value  
    

    chrome.tabs.query({ active: true, currentWindow: true },async function(tabs){
      let activeTab = tabs[0]
    

     console.log("activeTab",activeTab);
     if (!activeTab.id) throw new Error('No active tab found');

        const tabId = activeTab.id;

        console.log("tabId",tabId);  

        console.log("attaching debugger");
        
     await attachDebugger(tabId);
     console.log("input value",value);
     console.log("tabId",);
    chrome.runtime.sendMessage({message:"FLOW",input:value,tabId:tabId})

  });
    
    // chrome.tabs.query({active:true, currentWindow:true }, async (tabs) =>{
    //     const activeTab = tabs[0];
    //     console.log(activeTab.id);
    //     console.log('value in input', value);
    //     const response = await chrome.tabs.sendMessage({message:"FLOW",input:value})

    //     console.log("received in popup",response);
    // })
})

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    
  console.log('messageType',message.message)
  // console.log('id', message.id);
  // console.log('id',typeof message.id);


  if (message.message === "TS") {
   
  } 
 return true;
});



async function attachDebugger(tabId) {
    console.log("inside debugger func");
    return new Promise((resolve, reject) => {
      try {
        chrome.debugger.attach({ tabId }, '1.2', async () => {
          if (chrome.runtime.lastError) {
            console.error(
              'Failed to attach debugger:',
              chrome.runtime.lastError.message
            );
            reject(
              new Error(
                `Failed to attach debugger: ${chrome.runtime.lastError.message}`
              )
            );
          } else {
            console.log('attached to debugger');
            await chrome.debugger.sendCommand({ tabId }, 'DOM.enable');
            console.log('DOM enabled');
            await chrome.debugger.sendCommand({ tabId }, 'Runtime.enable');
            console.log('Runtime enabled');
            resolve();
          }
        });
      } catch (e) {
        reject(e);
      }
    });
}
