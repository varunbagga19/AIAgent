/* eslint-disable no-undef */

// let tabId;

// chrome.tabs.onUpdated.addListener(function(tabid,c){
//   tabId = tabid
// })
  
  // async function getActiveTab() {
  //   try {
  //     const activeTab = await chrome.tabs.query({ active: true, currentWindow: true });
  
  //     if (activeTab && !tabId) {
  //        tabId = activeTab[0].id;
  
  //       // Do something with the tabId
  //       console.log('Active Tab ID:', tabId);
  //     } else {
  //       throw new Error('No active tab found');
  //     }
  //   } catch (error) {
  //     console.error('Error getting active tab:', error.message);
  //   }
  // }

  async function callRPC(type, payload,tabId) {
    console.log("Entering callRRPC");
    console.log("sending message to content script",payload);
    console.log("type in rpc", type);
    console.log("in callRPC func", tabId);

    const response = await chrome.tabs.sendMessage(tabId ,{
      message: type,
      id: payload,
    });
    console.log("Leaving callRRPC");
    return response
}
// chrome.debugger.sendCommand(debuggeeId, command, commandParams, function(response) {
//     if (chrome.runtime.lastError) {
//         // Handle error: chrome.runtime.lastError.message contains the error message
//         console.error(chrome.runtime.lastError.message);
//     } else {
//         // Command was successful, process the response
//     }
// });

async function sendCommand(method, tabId ,params = null) {
  
    let reponseDB = chrome.debugger.sendCommand({ tabId }, method, params);
    // console.log("Debugger response",reponseDB);
    return reponseDB
}

const TOTALITY_ELEMENT_SELECTOR = 'data-totality-node-id';

  
async function getObjectId(originalId,tabId) {
  console.log("Entering in getObjectId");
    const message = await callRPC('UNIQUE_ID',originalId,tabId);
    // get node id
    const uniqueId = message.message;
    console.log("uniqueId of node",uniqueId);
    console.log("tabId",tabId);
    const document = (await sendCommand('DOM.getDocument',tabId));
    console.log('document', document);
    const { nodeId } = (await sendCommand('DOM.querySelector', tabId ,{
      nodeId: document.root.nodeId,
      selector: `[${TOTALITY_ELEMENT_SELECTOR}="${uniqueId}"]`,
    }));
    console.log('nodeId', nodeId);
    if (!nodeId) {
      throw new Error('Could not find node');
    }
    // get object id
    const result = (await sendCommand('DOM.resolveNode', tabId ,{ nodeId }));
    console.log();
  
    const objectId = result.object.objectId;
    console.log('objectId', objectId);
  
    if (!objectId) {
      throw new Error('Could not find object');
    }
    console.log("Leaving in getObjectId");
    return objectId;
}
  
  async function scrollIntoView(objectId,tabId) {
    console.log("Entering scrollInto");
    await sendCommand('Runtime.callFunctionOn', tabId,{
      objectId,
      functionDeclaration: scrollScriptString,
    });
    console.log("Leaving scrollInto");
    // await sleep(1000);
  }

  const scrollScriptString = scrollIntoViewFunction.toString();

  
  async function getCenterCoordinates(objectId, tabId) {
    console.log("Entering getCoord ");
    console.log("objectid in getCoordinates",objectId)
    console.log("tabId",tabId)

    try {
      const { model } = (await sendCommand('DOM.getBoxModel',tabId, { objectId }));
      const [x1, y1, x2, y2, x3, y3, x4, y4] = model.border;
      const centerX = (x1 + x3) / 2;
      const centerY = (y1 + y3) / 2;
      console.log("Leaving getCoord ");
      return {x: centerX, y: centerY };
    }catch(e){

    }
   
  }
  
  const delayBetweenClicks = 1000; // Set this value to control the delay between clicks
  const delayBetweenKeystrokes = 100; // Set this value to control typing speed
  
  async function clickAtPosition(x, y, tabId ,clickCount = 1) {
    console.log("Entering click Atposition");
    await sendCommand('Input.dispatchMouseEvent',tabId, {
      type: 'mousePressed',
      x,
      y,
      button: 'left',
      clickCount,     
    });
    await sendCommand('Input.dispatchMouseEvent',tabId, {
      type: 'mouseReleased',
      x,
      y,
      button: 'left',
      clickCount,
    });
    console.log("Leaving click Atposition");
    // await sleep(delayBetweenClicks);
  }
  
  async function click(payload,tabId) {
    console.log("Entering click");
    const objectId = await getObjectId(payload.elementId,tabId);
    await scrollIntoView(objectId,tabId);
    const { x, y } = await getCenterCoordinates(objectId,tabId);
    await clickAtPosition(x, y, tabId);
    console.log("Leaving click");
  }
  
  async function selectAllText(x, y,tabId) {
    console.log("Entering selecAllText");
    await clickAtPosition(x, y, tabId ,3);
    console.log("Leaving selecAllText");
  }
  let clickFirstTime = true
  let setvalueFirstTime = true  
  let GOTOFirstTime = true

  // function updateListener(tabID, changeInfo) {
  //   if (changeInfo.status == 'complete') {
  //         InfiniteTime()
  //     chrome.tabs.onUpdated.removeListener(updateListener);
  //   }
  // }

async function updateTab(tabId, URL) {
    return await new Promise((resolve, reject) => {
        chrome.tabs.update(tabId, { url: URL }, function(tab) {
            console.log("This is inside .update() function");
            console.log(tab);
            chrome.tabs.onUpdated.addListener(function listener(updatedTabId, changeInfo) {
              if (updatedTabId === tabId && changeInfo.status === 'complete') {
                  // Remove listener once tab status is complete
                  chrome.tabs.onUpdated.removeListener(listener);
                  // Send message to the tab
                  // chrome.tabs.sendMessage(tabId, { message: "TS", T: tab });
                  // Resolve the promise with the updated tab object
                  resolve(tab);
              }
          });
        });
    });
}

  async function GO_TO(URL,tabId) {
    console.log("Entering Go_To URL");
    // Navigating to a specific URL within a Chrome extension
    // eslint-disable-next-line no-undef
    console.log("GO_To called");
    console.log("TAB ID IN GOT",tabId);
    console.log("URL IN GOTO",URL);
    // chrome.tabs.update(tabId, { url: URL }, function(tab){
    //   console.log("This is inside .update() function ");
    //   console.log(tab);
    //   chrome.tabs.sendMessage(tabId,{message:"TS",T:tab})
    // });

    await updateTab(tabId, URL)
    .then(updatedTab => {
        // Code to continue after the tab has been updated
        console.log("Tab updated successfully:", updatedTab);
        if(GOTOFirstTime){
          clickFirstTime = false
          setvalueFirstTime = false
          GOTOFirstTime = false
          InfiniteTime(tabId)
        }
    })
    .catch(error => {
        console.error("Error updating tab:", error);
    });

    // chrome.tabs.onUpdated.addListener(updateListener);
    console.log("Leaving Go_To URL");
  }

  
  async function typeText(text,tabId) {
    console.log("Entering type text");
    for (const char of text) {
      await sendCommand('Input.dispatchKeyEvent', tabId,{
        type: 'keyDown',
        text: char,
      });
      // await sleep(delayBetweenKeystrokes / 2);
      await sendCommand('Input.dispatchKeyEvent',tabId, {
        type: 'keyUp',
        text: char,
      });
      // await sleep(delayBetweenKeystrokes / 2);
    }
    console.log("Leaving type text");
  }
  
  async function blurFocusedElement(tabId) {
    const blurFocusedElementScript = `
        if (document.activeElement) {
          document.activeElement.blur();
        }
      `;
    await sendCommand('Runtime.evaluate', tabId,{
      expression: blurFocusedElementScript,
    });
  }
  
  async function setValue(payload,tabId) {
    console.log("Entering set Value");
    const objectId = await getObjectId(payload.elementId,tabId);
    await scrollIntoView(objectId, tabId);
    const { x, y } = await getCenterCoordinates(objectId, tabId);
  
    await selectAllText(x, y, tabId);
    await typeText(payload.value, tabId);
    console.log("Leaving set Value");
  }


async function chooseFunction(actionName,args,tabId) {

    if (actionName === "click"){
        console.log("Arguments of click",args);
        await click(args,tabId)
        if (clickFirstTime) {
          clickFirstTime = false
          setvalueFirstTime = false
          GOTOFirstTime = false
          InfiniteTime(tabId)
        }
        console.log("tabId in click",tabId);
        // InfiniteTime(tabId)
    }else if(actionName === "setValue"){
        console.log("Arguments of SetValue",args);
        await setValue(args,tabId)
        if (setvalueFirstTime){
            clickFirstTime = false
            setvalueFirstTime = false
            GOTOFirstTime = false
          InfiniteTime(tabId)
        }
        console.log("tabId in click",tabId);
        // InfiniteTime(tabId)
    } else if(actionName == "GO_TO"){
        console.log("Arguments of GO_TO",args);
        await GO_TO(args.URL,tabId)
          // if (GOTOFirstTime){
          //   clickFirstTime = false
          //   setvalueFirstTime = false
          //   GOTOFirstTime = false          
          // }
    }  
 }


 function scrollIntoViewFunction() {
    // @ts-expect-error this is run in the browser context
    this.scrollIntoView({
      block: 'center',
      inline: 'center',
      // behavior: 'smooth',
    });
  }

const availableActions = [
    {
      name: 'click',
      description: 'Clicks on an element',
      args: [
        {
          name: 'elementId',
          type: 'number',
        },
      ],
    },
    {
      name: 'setValue',
      description: 'Focuses on and sets the value of an input element',
      args: [
        {
          name: 'elementId',
          type: 'number',
        },
        {
          name: 'value',
          type: 'string',
        },
      ],
    },
    {
      name: 'finish',
      description: 'Indicates the task is finished',
      args: [],
    },
    {
      name: 'fail',
      description: 'Indicates that you are unable to complete the task',
      args: [],
    },
    {
      name: 'GO_TO',
      description:'Takes a URL and searches that URL in string format. If you dont find any promising stuff from the current content use this to relocate to the most helpfull url.',
      args: [
        {
          name: 'URL',
          type: 'string',
        },
      ],
    },
    // {
    //   name:'Clarify',
    //   description:'Use this after each action. This is not an action but just ask question to yourself if the current dom is related to prompt given by the user. If you find the task is completed mark it as finish() or try it again with some other action.',
    //   args:[]
    // }
  ];

  function parseResponse(text) { 
    const thoughtMatch = text.match(/<Thought>(.*?)<\/Thought>/);
    const actionMatch = text.match(/<Action>(.*?)<\/Action>/);
  
    if (!thoughtMatch) {
      return {
        error: 'Invalid response: Thought not found in the model response.',
      };
    }
  
    if (!actionMatch) {
      return {
        error: 'Invalid response: Action not found in the model response.',
      };
    }
  
    const thought = thoughtMatch[1];
    const actionString = actionMatch[1];
    const actionPattern = /(\w+)\((.*?)\)/;
    const actionParts = actionString.match(actionPattern);
  
    if (!actionParts) {
      return {
        error:
          'Invalid action format: Action should be in the format functionName(arg1, arg2, ...).',
      };
    }
  
    const actionName = actionParts[1];
    const actionArgsString = actionParts[2];
  
    const availableAction = availableActions.find(
      (action) => action.name === actionName
    );
  
    if (!availableAction) {
      return {
        error: `Invalid action: "${actionName}" is not a valid action.`,
      };
    }
  
    const argsArray = actionArgsString
      .split(',')
      .map((arg) => arg.trim())
      .filter((arg) => arg !== '');

    const parsedArgs = {};
  
    if (argsArray.length !== availableAction.args.length) {
      return {
        error: `Invalid number of arguments: Expected ${availableAction.args.length} for action "${actionName}", but got ${argsArray.length}.`,
      };
    }
  
    for (let i = 0; i < argsArray.length; i++) {
      const arg = argsArray[i];
      const expectedArg = availableAction.args[i];
  
      if (expectedArg.type === 'number') {
        const numberValue = Number(arg);
  
        if (isNaN(numberValue)) {
          return {
            error: `Invalid argument type: Expected a number for argument "${expectedArg.name}", but got "${arg}".`,
          };
        }
  
        parsedArgs[expectedArg.name] = numberValue;
      } else if (expectedArg.type === 'string') {
        const stringValue =
          (arg.startsWith('"') && arg.endsWith('"')) || (arg.startsWith("'") && arg.endsWith("'")) || (arg.startsWith("`") && arg.endsWith("`")) ? arg.slice(1, -1) : null;
  
        if (stringValue === null) {
          return {
            error: `Invalid argument type: Expected a string for argument "${expectedArg.name}", but got "${arg}".`,
          };
        }
  
        parsedArgs[expectedArg.name] = stringValue;
      } else {
        return {
          // @ts-expect-error this is here to make sure we don't forget to update this code if we add a new arg type
          error: `Invalid argument type: Unknown type "${expectedArg.type}" for argument "${expectedArg.name}".`,
        };
      }
    }
  
    const parsedAction = {
      name: availableAction.name,
      args: parsedArgs,
    };

    console.log("thought",thought);
    console.log("action",actionString);
    console.log("parsedAction",parsedAction);

    return {
      thought,
      action: actionString,
      parsedAction,
    };
  }
  
  


const formattedActions = availableActions.map((action,i)=>{
    const args = action.args
      .map((arg) => `${arg.name}: ${arg.type}`)
      .join(', ');
    return `${i + 1}. ${action.name}(${args}): ${action.description}`;
  })
  .join('\n');

console.log("formattedActions",formattedActions);

const systemMessage = `
You are a browser automation assistant.

You can use the following tools:

${formattedActions}

You will be be given a task to perform and the current state of the DOM. You will also be given previous actions that you have taken. You may retry a failed action up to one time.
Please give the proper detail of the html element you are going to interact with, give me the html element in thought.
Please try again if you meet fail() in the process.
Please perform each action at a time and if you find anythung relevant with the user prompt after completing each action please mark that as finish().
Please verify the current DOM Before finish() if it is related to user prompt or not.
If user has not provided any specefic details please be very general in your own selection.
Please be extremely sure and calrify your each action(click, setValue) by looking at the current content of the page and your previous actions, after your clarfication than take any other action.
Otherwise you will be a use less assistant.
This is an example of an action:

<Thought>I should click the add to cart button</Thought>
<Action>click(223)</Action>

You must always include the <Thought> and <Action> open/close tags or else your response will be marked as invalid.`;

console.log("systemMessage",systemMessage);


 async function determineNextAction(taskInstructions, previousActions, simplifiedDOM, notifyError ) {

    const model = 'gpt-4-1106-preview' ;
    const prompt = formatPrompt(taskInstructions,previousActions,simplifiedDOM) ;
    const key = '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' ;
    console.log("prompt",prompt);

    const requestBody = {
        "model": model,
        "messages": [
          {
            role: 'system',
            content: systemMessage,
          },
          { role: 'user', content: prompt},
        ],
        "max_tokens": 500,
        "temperature": 0,
        "stop": ['</Action>'],
      };

      const json = JSON.stringify(requestBody)
      console.log(json);
  
    for (let i = 0; i < 3; i++) {
      try {
        const completion = await fetchChatCompletion(key,json)

        // const completion = await openai.chat.completions.create({
        //   model: model,
        //   messages: [
        //     {
        //       role: 'system',
        //       content: systemMessage,
        //     },
        //     { role: 'user', content: prompt },
        //   ],
        //   max_tokens: 500,
        //   temperature: 0,
        //   stop: ['</Action>'],
        // });

        console.log("Complete completion from open ai",completion);
        console.log("completion from open ai",completion.choices);
  
        return {
          usage:completion.usage.total_tokens,
          prompt,
          response:
            completion.choices[0].message?.content?.trim() + '</Action>',
        };
      } catch (error) {
        console.log('determineNextAction error', error);
        if (error.response.data.error.message.includes('server error')) {
          // Problem with the OpenAI API, try again
          if (notifyError) {
            console.log("error from h1");
            notifyError(error.response.data.error.message);
          }
        } else {
            console.log("error from h2");
          // Another error, give up
          throw new Error(error.response.data.error.message);
        }
      }
    }
    throw new Error(
      `Failed to complete query after ${3} attempts. Please try again later.`
    );
  }
  async function fetchChatCompletion(apiKey, json) {
    try {
        const response = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`
            },
            body: json
        });

        if (!response.ok) {
            if (response.status === 401) {
                // Unauthorized - Incorrect API key
                throw new Error("Looks like your API key is incorrect. Please check your API key and try again.");
            } else {
                throw new Error(`Failed to fetch. Status code: ${response.status}`);
            }
        }

        return await response.json();
    } catch (error) {
        // Send a response to the popup script
        chrome.runtime.sendMessage({ error: error.message });

        console.error(error);
    }
}
  
   function formatPrompt(
    taskInstructions,
    previousActions,
    pageContents
  ) {
    let previousActionsString = '';
  
    if (previousActions.length > 0) {
      const serializedActions = previousActions
        .map(
          (action) =>
            `<Thought>${action.thought}</Thought>\n<Action>${action.action}</Action>`
        )
        .join('\n\n');
      previousActionsString = `You have already taken the following actions: \n${serializedActions}\n\n`;
    }
  
  
    return `The user requests the following task:
        
        ${taskInstructions}

        ${previousActionsString}
        
        Current time: ${new Date().toLocaleString()}
        
        Current page contents: ${pageContents}`;
  }


const handleError = (error) =>{
    console.error("an error occured",error);
}

async function detachDebugger(tabId) {
  const targets = await chrome.debugger.getTargets();
  const isAttached = targets.some(
    (target) => target.tabId === tabId && target.attached
  );
  if (isAttached) {
    chrome.debugger.detach({ tabId: tabId });
  }
}
let previuosActions = [] 

let Ins = ""

async function flow(instruction,tabId) {

    console.log("finding active tab "); 

      previuosActions = []
      Ins = instruction
      clickFirstTime = true
      setvalueFirstTime = true
      GOTOFirstTime = true
        
        console.log("sending to templatize html");

        // while(true){

            console.log("tabid", tabId);
            console.log("New Dom constructing");
            const response = await chrome.tabs.sendMessage(tabId,{message:"DOM"})

            console.log("response from Content script",response.message);
    
            const simplifiedDom = response.message
        
            // const currentDOM = templatize(simplifiedDom)
            // console.log("templatize html",currentDOM);
    
            console.log("next step will be calling api");
    
            console.log("previousAction",previuosActions);
    
            const query = await determineNextAction(Ins,previuosActions,simplifiedDom,handleError)
    
            console.log("open ai response",query);
    
            const action = parseResponse(query.response)

            console.log("action",action);
    
            previuosActions.push(action);
    
              console.log('this is the parsed action args',action.parsedAction.args);
    
              if (
                action === null ||
                action.parsedAction.name === 'finish' ||
                action.parsedAction.name === 'fail'
              ) {
                await detachDebugger(tabId)
                return ;
              }
    
              if (action.parsedAction.name === 'click') {
                await chooseFunction('click', action.parsedAction.args,tabId);
              } else if(action.parsedAction.name === 'setValue') {
                await chooseFunction('setValue', action.parsedAction.args,tabId);
              } else if(action.parsedAction.name === 'GO_TO') {
                await chooseFunction('GO_TO', action.parsedAction.args,tabId);
              }
    // }
}

async function InfiniteTime(tabId) {

  console.log("tabid", tabId);

  let count = 0;

    while(true) {
      console.log("New Dom constructing",count++);
        await sleep(2000);
        const response = await chrome.tabs.sendMessage(tabId,{message:"DOM"})

        console.log("response from Content script",response.message);

        const simplifiedDom = response.message

        // const currentDOM = templatize(simplifiedDom)
        // console.log("templatize html",currentDOM);

        console.log("next step will be calling api");

        console.log("previousAction",previuosActions);

        const query = await determineNextAction(Ins,previuosActions,simplifiedDom,handleError);

        console.log("open ai response",query);

        const action = parseResponse(query.response);

        console.log("action",action);

        previuosActions.push(action);

        console.log('this is the parsed action args',action.parsedAction.args);

          if (
            action === null ||
            action.parsedAction.name === 'finish' ||
            action.parsedAction.name === 'fail'
          ) {
            await detachDebugger(tabId)
            break ;
          }

          if (action.parsedAction.name === 'click') {
            await chooseFunction('click', action.parsedAction.args,tabId);
            await sleep(4000);
          } else if(action.parsedAction.name === 'setValue') {
            await chooseFunction('setValue', action.parsedAction.args,tabId);
            await sleep(2000);
          } else if(action.parsedAction.name === 'GO_TO') {
            await chooseFunction('GO_TO', action.parsedAction.args,tabId);
            await sleep(8000);
          }  
    }
}


async function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function getMeDOM(){
  const response =  chrome.tabs.sendMessage(tabId,{message:"DOM"})
}



chrome.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
    
    console.log("inside Background script")

    if (message.message === "FLOW") {
        console.log("hello");

     await flow(message.input,message.tabId)
    }
    // Return true to indicate that the response will be sent asynchronously
   return true;
});

