/* eslint-disable no-undef */
console.log("content script");

function range(start, end, step) {
    if (end === undefined) {
      end = start;
      start = 0;
    }
  
    if (step === undefined) {
      step = 1;
    }
  
    const result = [];
  
    for (let i = start; i < end; i += step) {
      result.push(i);
    }

    return result;
}


 function findPotentialTemplates(node,possibleTemplates) {
  if (node.nodeType === Node.ELEMENT_NODE) {
    const element = node ;
    const attributes = {};

    for (let i = 0; i < element.attributes.length; i++) {
      const attr = element.attributes[i];
      attributes[attr.name] = attr.value;
    }

    const children = [];

    for (const childNode of element.childNodes) {
      const childJson = findPotentialTemplates(childNode, possibleTemplates);
      if (childJson) {
        children.push(childJson);
      }
    }

    const depth = children.reduce((max, c) => Math.max(max, c.depth), 0) + 1;

    const templateHash = `${element.tagName}#${Object.keys(
      attributes
    ).sort()}#${children.map((c) => c.templateHash).join('|')}`;

    const templateValues = Object.values(attributes).concat(
      children.flatMap((c) => c.templateValues)
    );

    const jsonNode = {
      type: 'ELEMENT',
      tagName: element.tagName,
      attributes,
      children,
      templateHash,
      templateValues,
      depth,
    };

    if (possibleTemplates[templateHash]) {
      if (possibleTemplates[templateHash].depth !== depth) {
        console.error("Error in templetizing the code");
        throw new Error(`Template depth mismatch for template ${templateHash}`);
      }
      possibleTemplates[templateHash].nodes.push(jsonNode);
    } else {
      possibleTemplates[templateHash] = {
        hash: templateHash,
        nodes: [jsonNode],
        depth,
      };
    }

    return jsonNode;
  } else if (node.nodeType === Node.TEXT_NODE) {
    const text = node.textContent;
    if (text && text.trim()) {
      return {
        type: 'TEXT',
        content: text,
        templateHash: `TEXT`,
        templateValues: [text],
        depth: 0,
      };
    }
  }

  return null;
}

const optimizeTemplate = (template) => {
  // Find template values that are the same for all nodes
  const valuesToInline = range(template.nodes[0].templateValues.length).filter(
    (i) => {
      const values = template.nodes.map((n) => n.templateValues[i]);
      return values.every((v) => v === values[0]);
    }
  );

  return {
    ...template,
    valuesToInline: new Set(valuesToInline),
    // template: optimizedTemplate,
  };
};

function chooseTemplates(templates) {
  const chosenTemplates = {};
  const consumedTemplateCounts = {};

  for (const template of Object.values(templates).sort((t) => -t.depth)) {
    // If the template isn't used in at least 3 places, don't bother
    if (
      template.nodes.length - (consumedTemplateCounts[template.hash] ?? 0) <
        3 ||
      template.depth < 3
    ) {
      continue;
    }

    template.label = `T${Object.keys(chosenTemplates).length + 1}`;
    const serialized = createTemplateTree(
      template.nodes[0],
      chosenTemplates,
      template
    );
    template.template = serialized.template;
    chosenTemplates[template.hash] = template;
    serialized.consumedTemplates.forEach((t) => {
      consumedTemplateCounts[t] =
        (consumedTemplateCounts[t] ?? 0) + template.nodes.length;
    });
  }

  return chosenTemplates;
}

function getPlaceholder(template,valueIndex) {
  // valueIndex plus one minus the number of values below it that are inlined
  const placeholderIndex = valueIndex + 1 - Array.from(template.valuesToInline).filter((i) => i < valueIndex).length;
  return `$${placeholderIndex}`;
}

function createTemplateTree(node, templates, renderForTemplate, currentValueIndex = 0){
  if (node.type === 'TEXT') {
    if (renderForTemplate.valuesToInline.has(currentValueIndex)) {
      return {
        template: node.content,
        valueIndex: currentValueIndex + 1,
        consumedTemplates: [node.templateHash],
      };
    } else {
      return {
        template: getPlaceholder(renderForTemplate, currentValueIndex),
        valueIndex: currentValueIndex + 1,
        consumedTemplates: [node.templateHash],
      };
    }
  }

  let updatedValueIndex = currentValueIndex;
  const consumedTemplates = [node.templateHash];

  const attrs = Object.entries(node.attributes)
    .map(([k, v], i) => {
      if (renderForTemplate.valuesToInline.has(updatedValueIndex + i)) {
        return ` ${k}="${v}"`;
      } else {
        return ` ${k}=${getPlaceholder(
          renderForTemplate,
          updatedValueIndex + i
        )}`;
      }
    })
    .join('');

  updatedValueIndex += Object.keys(node.attributes).length;

  const children = [];
  for (const child of node.children) {
    const childTemplate = createTemplateTree(
      child,
      templates,
      renderForTemplate,
      updatedValueIndex
    );
    children.push(childTemplate.template);
    updatedValueIndex = childTemplate.valueIndex;
    consumedTemplates.push(...childTemplate.consumedTemplates);
  }

  const isSelfClosing = node.children.length === 0;

  return {
    template: `<${node.tagName.toLowerCase()}${attrs}${
      isSelfClosing
        ? '/>'
        : `>${children.join('')}</${node.tagName.toLowerCase()}>`
    }`,
    valueIndex: updatedValueIndex,
    consumedTemplates,
  };
}

function isStringANumber(str) {
  return !isNaN(parseFloat(str)) && isFinite(str);
}

function serializeTree(node, templates) {
  if (node.type === 'TEXT') {
    return node.content;
  }

  // Check if the node's templateHash matches one of the chosen templates
  if (node.templateHash in templates) {
    const template = templates[node.templateHash];

    return `{${template.label}(${node.templateValues
      .filter((v, i) => !template.valuesToInline.has(i))
      .map((v) => (isStringANumber(v) ? v : JSON.stringify(v)))
      .join(',')})}`;
  }

  const attrs = Object.entries(node.attributes)
    .map(([k, v]) => ` ${k}="${v}"`)
    .join('');

  const children = node.children
    .map((child) => serializeTree(child, templates))
    .join('');

  const isSelfClosing = node.children.length === 0;

  return `<${node.tagName.toLowerCase()}${attrs}${
    isSelfClosing ? '/>' : `>${children}</${node.tagName.toLowerCase()}>`
  }`;
}

function templatize(html) {
  const doc = new DOMParser().parseFromString(html, 'text/html');
  const root = doc.documentElement;

  const possibleTemplates = {};

  const tree = findPotentialTemplates(root, possibleTemplates);
  if (!tree) return html;
  console.log("TREE",tree);
  console.log("POSSIBLE_TEMPLATES",possibleTemplates);

  const optimizedTemplates = Object.values(possibleTemplates).reduce(
    (acc, template) => {
      const optimized = optimizeTemplate(template);
      return {
        ...acc,
        [optimized.hash]: optimized,
      };
    },
    {}
  );

  // Choose which templates to apply
  const chosenTemplates = chooseTemplates(optimizedTemplates);

  const printedTemplates = Object.values(chosenTemplates)
    .map((t) => `${t.label}: ${t.template}`)
    .join('\n');

  // Apply chosen templates to the tree
  const templatizedTree = serializeTree(tree, chosenTemplates);

  return printedTemplates + '\n\n' + templatizedTree;
}


function isInteractive(element,style){

    return ( element.tagName === 'A' ||
    element.tagName === 'INPUT' ||
    element.tagName === 'BUTTON' ||
    element.tagName === 'SELECT' ||
    element.tagName === 'TEXTAREA' ||
    element.hasAttribute('onclick') ||
    element.hasAttribute('onmousedown') ||
    element.hasAttribute('onmouseup') ||
    element.hasAttribute('onkeydown') ||
    element.hasAttribute('onkeyup') ||
    style.cursor === 'pointer'
    )
}

function isVisible(element, style) {
    return (
      style.opacity !== '' &&
      style.display !== 'none' &&
      style.visibility !== 'hidden' &&
      style.opacity !== '0' &&
      element.getAttribute('aria-hidden') !== 'true'
    );
}

let currentElements = []

function traverseDOM(node, pageElements) {

    const clonedNode = node.cloneNode(false);

    if (node.nodeType === Node.ELEMENT_NODE) {
    const element = node;
    const style = window.getComputedStyle(element);

    // console.log('element',element);
    // console.log('style',style);

    const clonedElement = clonedNode;

    pageElements.push(element);
    clonedElement.setAttribute('data-id', (pageElements.length - 1).toString());
    clonedElement.setAttribute(
      'data-interactive',
      isInteractive(element, style).toString()
    );

    clonedElement.setAttribute( 
      'data-visible',
      isVisible(element, style).toString()
    );

  }

  node.childNodes.forEach((child) => {
    const result = traverseDOM(child, pageElements);
    clonedNode.appendChild(result.clonedDOM);
  });

  return {
    pageElements,
    clonedDOM: clonedNode,
  };
}

// console.log("traversed DOM",traverseDOM(document.documentElement,currentElements).clonedDOM);

function getDOM() {
  return traverseDOM(document.documentElement,currentElements)
}

// console.log("getDom function",getDOM().clonedDOM);



function truthyFilter(value) {
  return Boolean(value);
}

function SimplifiedDom(element,interactiveElements) {
  if (element.nodeType === Node.TEXT_NODE && element.textContent?.trim()) {
    return document.createTextNode(element.textContent + ' ');
  }

  if (!(element instanceof HTMLElement || element instanceof SVGElement))
    return null;

  const isVisible = element.getAttribute('data-visible') === 'true';
  if (!isVisible) return null;

  let children = Array.from(element.childNodes)
    .map((c) => SimplifiedDom(c, interactiveElements))
    .filter(truthyFilter);

    if (element.tagName === 'BODY')
    children = children.filter((c) => c.nodeType !== Node.TEXT_NODE);

  const interactive =
    element.getAttribute('data-interactive') === 'true' ||
    element.hasAttribute('role');
  const hasLabel =
    element.hasAttribute('aria-label') || element.hasAttribute('name');
  const includeNode = interactive || hasLabel;

  if (!includeNode && children.length === 0) return null;
  if (!includeNode && children.length === 1) {
    return children[0];
  }

  const container = document.createElement(element.tagName);

  const allowedAttributes = [
    'aria-label',
    'data-name',
    'name',
    'type',
    'placeholder',
    'value',
    'role',
    'title',
  ];

  for (const attr of allowedAttributes) {
    if (element.hasAttribute(attr)) {
      container.setAttribute(attr, element.getAttribute(attr));
    }
  }
  if (interactive) {
    interactiveElements.push(element);
    container.setAttribute('id', element.getAttribute('data-id'));
  }

  children.forEach((child) => container.appendChild(child));

  return container;
}

// let complete = false

// document.addEventListener('load', function(event) {
//   console.log("Document readystate",document.readyState);
//   if (document.readyState === "complete"){
//     console.log("document is completely loaded");
//     complete = true
//   }
// },true);

// document.addEventListener("readystatechange", (event) => {
//   if (event.target.readyState === "interactive"){
//     console.log("DOM interactive");
//   } else if (event.target.readyState === "complete"){
//     complete = true
//     console.log("DOM is ready from contentscript now the DOM message should be called");
//   }
// });

// document.addEventListener('load', function(event) {
//   console.log('document - load - capture',"EDITED_VARUN",event); // DOES NOT HAPPEN
// },true);


function getSimplifiedDom() {
  const fullDom = getDOM().clonedDOM.outerHTML;
  if (!fullDom) return null;

  const dom = new DOMParser().parseFromString(fullDom, 'text/html');

  const interactiveElements = [];

  const simplifiedDom = SimplifiedDom(
    dom.documentElement,
    interactiveElements
  );
  console.log("simplifiedDom",simplifiedDom);

  return  templatize(simplifiedDom.outerHTML);
}

function getUniqueElementSelectorId(id) {
  console.log("Id of the element",id);
  const element = currentElements[id];
  console.log("size of currenEle",currentElements);
  console.log("element in cs",element);
  // element may already have a unique id
  let uniqueId = element.getAttribute('data-totality-node-id');
  if (uniqueId) return uniqueId;
  uniqueId = Math.random().toString(36).substring(2, 10);
  element.setAttribute('data-totality-node-id', uniqueId);
  return uniqueId;
}


// eslint-disable-next-line no-undef
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    
    console.log('messageType',message.message)
    // console.log('id', message.id);
    // console.log('id',typeof message.id);


    if (message.message === "DOM") {
      // currentElements = []
      console.log("inside DOM message");
      // console.log("checking null",document.getElementById(message.id) === null );
      // console.log("Element ",document.getElementById(message.id.toString()));
      // document.getElementById(message.id).click();
      sendResponse({message: getSimplifiedDom()})
    } else if (message.message === "UNIQUE_ID") {
      console.log("here for getting unique element");
      sendResponse({message:getUniqueElementSelectorId(message.id)})
    } 
    // Return true to indicate that the response will be sent asynchronously
   return true;
});


var iframe = document.createElement("iframe");
iframe.src = chrome.runtime.getURL("index.html");

// Apply the CSS styles
iframe.style.top = "10";
iframe.style.right = "0";
iframe.style.bottom = "0";
iframe.style.margin = "0";
iframe.style.padding = "0";
iframe.style.width = "25%";
iframe.style.height = "50px";
iframe.style.display = "block";
iframe.style.position = "fixed";
iframe.style.zIndex = "2147483646";
iframe.style.backgroundColor = "white";
iframe.style.border = "none";
iframe.style.borderLeft = "1px solid #ccc";
iframe.style.boxShadow = "-7px 2px 14px -7px rgba(163,163,163,1)";

document.body.appendChild(iframe);
